
function showForm() {
  document.getElementById('ticketForm').style.display = 'block';
}

document.getElementById('giveawayForm').addEventListener('submit', function(e) {
  e.preventDefault();
  const name = document.getElementById('name').value;
  const message = encodeURIComponent(`Hi, I'm ${name}. I just submitted my fan ticket info.`);
  window.location.href = `https://wa.me/447446430308?text=${message}`;
});
